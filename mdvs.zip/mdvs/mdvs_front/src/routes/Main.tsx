import {
  Box, HStack, Text, VStack, Stack, Menu, Heading, MenuButton, MenuList, MenuItem,
  Checkbox, Input, Button
} from "@chakra-ui/react";
import React, {useState} from "react";
import { getCommentResponse } from "../api";
import {useQuery} from "@tanstack/react-query"


function Selection(props: any) {
  return (
    <VStack>
      <Menu>
        <Heading size='sm'>{props.name}</Heading>
        <MenuButton
        width={'8rem'}
        px={4}
        py={2}
        transition={'all 0.2s'}
        borderWidth={'1px'}>
          {props.default}
        </MenuButton>
        <MenuList>
          <MenuItem>{props.default}</MenuItem>
          <MenuItem>{props.default}</MenuItem>
          <MenuItem>{props.default}</MenuItem>
          <MenuItem>{props.default}</MenuItem>
        </MenuList>
      </Menu>
    </VStack>
  )

}

function Check(props: any) {
  return (
    <Checkbox defaultChecked>{props.name}</Checkbox>
  )
}

function Result(props: any) {
  return (
    <Stack spacing={0}>
      <Heading size={'sm'}>{props.desc}</Heading>
      <Text>{props.val}</Text>
    </Stack>
  )
}

export function Main() {
const [keyWord, setKeyword] = useState<string>('')
const { data, isLoading } = useQuery(['commentResponse', keyWord], getCommentResponse);

  return (
    <Stack height="100vh" w='80%' display="flex" flexDirection="column" spacing={5} px={10} py={10}>
      <HStack alignItems="flex-end" spacing={5}>
        <Selection name='PROJECT SELECT' default='SN2333' />
        <Selection name='GROUP SELECT' default='ARCH' />
        <Check name='PMS CHECKING' />
        <Check name='SHI MATERIAL CODE MATCHING' />
      </HStack>
      <Stack>
      <Heading size={'md'}>DESCRIPTION INPUT</Heading>
      <HStack>
        <Input 
        placeholder='트레이닝룸 김나지움'
        width='40rem' />
        <Button>SEARCH</Button>
      </HStack>
      </Stack>
      <Heading size={'md'}>RESULT DESCRIPTION</Heading>
      <Result desc='(Similarity Score)' val='[0.8101149, 0.8101149, 0.8101149, 0.8101149, 0.8101149,]' />
      <Result desc='(Index No.)' val='[0.8101149, 0.8101149, 0.8101149, 0.8101149, 0.8101149,]' />
      <Result desc='(Comments Searched)' val='[0.8101149, 0.8101149, 0.8101149, 0.8101149, 0.8101149,]' />
      <Heading mt={'auto'} ml='auto' size={'sm'}>Response Time 2.34 sec</Heading>
    </Stack>  
  );
}

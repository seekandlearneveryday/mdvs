import { QueryFunctionContext } from "@tanstack/react-query";
import axios from "axios";


const service = axios.create({baseURL: 'http://60.100.91.165:31223/'})

type Comment = [string, string];

export const getCommentResponse = ({ queryKey }: QueryFunctionContext<Comment>) => {
  const [key, keyWord] = queryKey
  return service.get('comment_response')
    .then((response) => response.data)}
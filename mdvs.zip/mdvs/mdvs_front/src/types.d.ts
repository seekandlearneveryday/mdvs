
export interface ICommentResponse{
    [key:number]:{
        query:string,
        sim_score:Float32Array,
        sim_index:Float32Array,
        sim_sents:Array<string>
    }
}
import { ChakraProvider, ColorModeScript } from "@chakra-ui/react"
import * as React from "react"
import * as ReactDOM from "react-dom/client"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { RouterProvider, createBrowserRouter } from "react-router-dom"
import { Main } from "./routes/Main"

const client = new QueryClient({
  defaultOptions:{
    queries:{
  
      staleTime: 50000,
      retry:false,
      refetchOnWindowFocus:false
    }
  }
})

function Router(){
  return createBrowserRouter([{
   
    children:[
      {path: '',
    element: <Main/>
  }
    ]
  }])
}

function App(){
  return (
    <QueryClientProvider client={client}>
<ChakraProvider>
  <RouterProvider router={Router()}/>
</ChakraProvider>
    </QueryClientProvider>
  )
}

const root = ReactDOM.createRoot(document.getElementById('root')|| new HTMLElement())

root.render(<App/>)
// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://cra.link/PWA

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

